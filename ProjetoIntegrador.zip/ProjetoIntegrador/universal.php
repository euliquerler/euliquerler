<?php 
    include_once ("_cabecalho.php");
    include_once ("connection.php");
  $conn = getConnection();
  $id = $_GET["id"];
  $sql = "SELECT CadastroLivro.*, CadastroUsuario.* FROM CadastroLivro, CadastroUsuario 
  WHERE (idLivro = :id) AND CadastroLivro.proprietario = CadastroUsuario.id";
  $stmt = $conn->prepare($sql);
  $stmt->bindValue(":id",$id);
  $stmt->execute();
  $livro = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
    <?php
      foreach ($livro as $value) { ?>
        <form action="" >        
        <fieldset>
        <legend><?= $value["titulo"] ?></legend>
        <p style="text-align: center;"><b>Autor:</b> <?= $value["autor"] ?></p>
        <p style="text-align: center;"><b>Gênero:</b> <?= $value["genero"] ?></p>
        <p style="text-align: center;"><b>Ano da edição:</b> <?= $value["ano"] ?></p>
        <p style="text-align: center;"><b>Editora:</b> <?= $value["editora"] ?></p>
        <p style="text-align: center;"><b>Categoria:</b> <?= $value["categoria"] ?></p>
        <p style="text-align: center;"><b>Proprietário:</b> <?= $value["nome"];?></p>
        <p style="text-align: center;"><b>Sinopse:</b> <?= $value["sinopse"] ?></p>
        <p style="text-align: center;"><b>Para entrar em contato com o proprietário do livro, envie-lhe um email para:</b> <?= $value["email"] ?></p>



        </fieldset>  
        </form>
    <?php
    }?>
<?php
    include_once ("_rodape.php");
?>