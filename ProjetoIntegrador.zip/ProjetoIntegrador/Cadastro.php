  <?php
    include_once ("_cabecalho.php");  
    exec("SET CHARACTER SET utf8");  

    function InserirDados($nome, $sobrenome, $email, $telefone, $sexo, $senha){ 
      include_once ("inc/connection.php");
      $conn = getConnection();
      $sql = "INSERT INTO CadastroUsuario (nome, sobrenome, email, senha, telefone, sexo) 
      VALUES(:nome, :sobrenome, :email, :senha, :telefone, :sexo)"; 
      $stmt = $conn->prepare($sql);
      $stmt->bindValue(":nome",$nome);
      $stmt->bindValue(":sobrenome",$sobrenome);
      $stmt->bindValue(":email",$email);
      $stmt->bindValue(":senha",$senha);
      $stmt->bindValue(":telefone",$telefone);
      $stmt->bindValue(":sexo",$sexo);
      $stmt->execute();
    }
    
    if (isset($_POST["nome"]) && isset($_POST['sobrenome']) && isset($_POST["email-cadastro"]) && isset($_POST["telefone"]) 
    && isset($_POST["sltSexo"]) && isset($_POST["senha-cadastro"]) ) {
      $nome = $_POST["nome"];
      $sobrenome = $_POST["sobrenome"];
      $email = $_POST["email-cadastro"];
      $telefone = $_POST["telefone"];
      $sexo = $_POST["sltSexo"];
      $senha = $_POST["senha-cadastro"];
      InserirDados($nome, $sobrenome, $email, $telefone, $sexo, $senha);
    }


    
    
  ?>
  

  <div class="container">
    <div class="row">
      <div class="col-md-3">
      </div>
      <div class="col-sm-12 col-md-6 cadastro">
        <form action="login.php" method="POST" name="formulario-cadastro">
            <b><label for="nome">Nome</label></b>
            <input class="form-control" type="text" name="nome" maxlength="60" id="nome" placeholder="Joãozinho" required>
            <b><Label for="sobrenome">Sobrenome</Label></b>
            <input type="text" name="sobrenome" id="sobrenome" class="form-control" maxlength="40" placeholder="Silva" required>
            <b><label for="email-cadastro">Endereço de email</label></b>
              <input type="email" class="form-control" id="email-cadastro" maxlength="100" required name="email-cadastro" placeholder="email@exemplo.com">
            <b><label for="telefone">Telefone</label></b>
            <input class="form-control" type="tel" name="telefone" id="telefone" required placeholder="(00)999999999"  maxlength="15" >
            <br>
            <select name="sltSexo" class="select form-control" id="sexo" required>
              <option value="">Selecione o sexo</option>
              <option value="F">Feminino</option>
              <option value="M">Masculino</option>
              <option value="PFN"> Prefiro não informar</option>
            </select>
            <b><label for="senha-cadastro">Senha</label></b>
              <input type="password" class="form-control" name="senha-cadastro" maxlength="20" id="senha-cadastro" placeholder="Senha" required>
            <b><label>Confirmar senha </label></b>
              <input type="password" class="form-control" required name="ConfirmSenha" maxlength="20" id="ConfirmSenha" placeholder="Confirmação da senha"/>
              <button type="submit" class="btn">Cadastre-se</button>
          </form>
      </div>      
    </div>
  </div>
  <?php
  include_once ("_rodape.php");
  ?>    