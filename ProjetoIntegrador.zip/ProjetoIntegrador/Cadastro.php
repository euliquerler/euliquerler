<?php
include_once ("_cabecalho.php");
session_start();
  if (isLoggedIn())
  {
    header('Location: Perfil.php');
  }
?>


  <div class="container">
    <div class="row">
      <div class="col-md-3">
      </div>
      <div class="col-sm-12 col-md-6 cadastro">
        <form action="cadastrar.php" method="POST" name="formulario-cadastro"  id="FormCadUs">
            <b><label for="nome">Nome</label></b>
            <input class="form-control" type="text" name="nome" minlength="3" maxlength="60" id="nome" placeholder="Joãozinho" required>
            <b><Label for="sobrenome">Sobrenome</Label></b>
            <input type="text" name="sobrenome" id="sobrenome" class="form-control" minlength="3"  maxlength="40" placeholder="Silva" required>
            <b><label for="email-cadastro">Endereço de email</label></b>
              <input type="email" class="form-control" id="email-cadastro" maxlength="100" required name="email-cadastro" placeholder="email@exemplo.com">
            <b><label for="telefone">Telefone</label></b>
            <input class="form-control" type="tel" name="telefone" id="telefone" pattern="[0-9]+$" required placeholder="(00)999999999" minlength="11"  maxlength="15" >
            <br>
            <select name="sltSexo" class="select form-control" id="sexo" required>
              <option value="">Selecione o sexo</option>
              <option value="F">Feminino</option>
              <option value="M">Masculino</option>
              <option value="PFN"> Prefiro não informar</option>
            </select>
            <b><label for="senha-cadastro">Senha</label></b>
              <input type="password" class="form-control" name="senha-cadastro" minlength="5" maxlength="20" id="senha-cadastro" placeholder="Senha" required>
              <button type="submit" class="btn">Cadastre-se</button>
          </form>
      </div>
    </div>
  </div>
  <?php
  include_once ("_rodape.php");
  ?>
