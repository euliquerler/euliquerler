<?php
  include_once ("_cabecalho.php");
  session_start();
    if (isLoggedIn())
    {
      header('Location: Perfil.php');
    }

?>

    <br>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-12 login">
          <form action="logar.php" method="post" id="FormLog">
            <b><label for="email-login">Endereço de email</label></b>
            <input type="email" class="form-control" name="email-login" id="email-login" placeholder="email@exemplo.com">
            <br>
            <b><label for="senha-login">Senha</label></b>
            <input type="password" class="form-control" name="senha-login" id="senha-login" minlength="5" placeholder="Senha">
            <button type="submit" class="btn">Entrar</button>
          </form>
        </div>
        <div class="col-md-6 col-sm-12 login">
          <form class="cadastre-se" action="Cadastro.php">
            <b><label for="">Ainda não estou cadastrado</label></b>
            <p>Para o compartilhamento de livros em nosso site, é preciso que você cadastre-se. A partir do cadastro,
            você poderá ter acesso aos livros que estão disponíveis para doações, empréstimos e trocas. Não é tão rápido,
            mas garanto que é fácil. Clique no botão abaixo e cadastre-se.</p>
            <button class="btn cadastre-se" type="submit">Cadastre-se</button>
          </form>
        </div>
      </div>
    </div>
<?php
  include_once ("_rodape.php");
?>
