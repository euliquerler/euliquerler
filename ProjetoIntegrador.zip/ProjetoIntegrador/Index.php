<?php
  include_once ("_cabecalho.php");
  include_once ("_rodape.php");
?>  
