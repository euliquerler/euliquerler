<?php
 
// constantes com as credenciais de acesso ao banco MySQL
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '130700');
define('DB_NAME', 'Eu_li_quer_ler');
 
// habilita todas as exibições de erros
ini_set('display_errors', true);
error_reporting(E_ALL);
 
?>