<?php
 
require_once 'init.php';
require_once 'Function.php';
require 'check.php';
include_once ("_cabecalho.php");

?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Perfil do Usuário</title>
    </head>
 
    <body>
        <form action="" >        
        <fieldset>
        <legend>Perfil do Usuário</legend>
        <p style="text-align: center;">Bem-vindo ao seu perfil, <?php echo $_SESSION['nome']; ?></p>
        <p style="text-align: center;">Nome: <?php echo $_SESSION['nome']; echo "\n"; echo $_SESSION['sobrenome'];?></p>
        <p style="text-align: center;">Email: <?php echo $_SESSION['email']; ?></p>
        <p style="text-align: center;">Telefone <?php echo $_SESSION['telefone']; ?></p>


            
        <a href="CadastroLivro.php"><button id="login" class="btn" type="button"> Cadastrar livro</button></a>
        <a href="logout.php"><button id="login" style="margin-left: 5px"  class="btn" type="button"> Sair</button></a>
        </fieldset>  
        </form>

    </body>
</html>
<?php
  include_once ("_rodape.php");
?>