<?php
    include_once ("_cabecalho.php");
?>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-3">
      </div>
      <div class="col-sm-12 col-md-6 cadastro">
        <form action="cadastrarLivro.php" method="post" id="FormCadLi">
            <b><label >Imagem do Livro</label></b>
            <input type="file" name="imagemLivro" id="imagem"class="form-control"> 
            <b><label >Titulo</label></b>
            <input class="form-control" type="text" name="titulo" id="Titulo" required minlength="3" placeholder="A menina que roubava livros">
            <b><LAbel>Autor</LAbel></b>
            <input type="text" name="autor" id="Autor" class="form-control" required minlength="3" placeholder=" Markus Zusak">
            <b><label>Gênero</label></b>
              <input type="text" name="genero"class="form-control" id="Genero" required minlength="3" placeholder="Romance">
            <b><label>Ano da edição</label></b>
              <input type="number" name="ano" class="form-control" id="AnoE" required minlength="2" placeholder="2007">
            <b><label>Editora</label></b>
              <input type="text" name="editora" class="form-control" id="Editora" required minlength="3"  placeholder="Intriseca">
            <b><label>Sinopse</label></b>
              <textarea type="" name="sinopse" class="form-control" id="Sinopse" required minlength="10" maxlength="299"
              placeholder="Durante a Segunda Guerra Mundial, uma jovem garota chamada Liesel Meminger sobrevive fora de Munique
               através dos livros que ela rouba. Ajudada por seu pai adotivo, ela aprende a ler e partilhar livros com seus 
               amigos, incluindo um homem judeu que vive na clandestinidade em sua casa."></textarea>  
            <b><label>Categoria</label></b><br>
            <select name="categoria" class="select form-control" id="categoria" required>
              <option value="">Selecione a categoria</option>
              <option value="Doações">Doações</option>
              <option value="Empréstimos">Empréstimos</option>
              <option value="Trocas">Trocas</option>
            </select>
              <button type="submit" class="btn">Cadastrar</button>
          </form>
      </div>
    </div>
  </div>
  <?php
    include_once ("_rodape.php");
  ?>



  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
