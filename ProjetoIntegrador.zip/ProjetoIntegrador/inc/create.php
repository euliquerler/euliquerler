<?php
include_once ("connection.php");

$conn = getConnection();

$sql = 'insert into CadastroUsuario (nome, sobrenome) values (?,?)';

$nome = 'Thais';
$sobrenome = 'Alves';
$stmt = $conn->prepare($sql);
$stmt ->bindParam(1,$nome);
$stmt ->bindParam(2,$sobrenome);
if ($stmt ->execute()) {
    echo 'Salvo com sucesso';
} else {
    echo 'erro';
}

?>