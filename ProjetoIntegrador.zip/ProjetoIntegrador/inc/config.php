<?php 
return [
    // variáveis da bd
    'BD_HOST'           => 'localhost',
    'BD_DATABASE'       => 'Eu_li_quer_ler',
    'BD_CHARSET'        => 'utf8',
    'BD_USERNAME'       => 'root',
    'BD_PASSWORD'       => '130700',
]   

// coloca $configs = include(config.php)
?>