<?php
require_once 'init.php';
require_once 'Function.php';
session_start();

if (!isLoggedIn())
{
    header('Location: Login.php');
}
?>