<?php

exec("SET CHARACTER SET utf8");
  include_once ("connection.php");
  $conn = getConnection();
  $nome = isset($_POST["nome"]) ? $_POST["nome"]:'';
  $sobrenome = isset($_POST["sobrenome"]) ? $_POST["sobrenome"]:'';
  $email = isset($_POST["email-cadastro"]) ? $_POST["email-cadastro"]:'';
  $telefone = isset($_POST["telefone"]) ? $_POST["telefone"]:'';
  $sexo = isset($_POST["sltSexo"]) ? $_POST["sltSexo"]:'';
  $senha = isset($_POST["senha-cadastro"]) ? $_POST["senha-cadastro"]:'';


  if (empty($email) || empty($senha) || empty($sobrenome) || empty($email) || empty($telefone) || empty($sexo)) {
      echo "Preencha todos os dados!";
      exit;
  }
  $sql = "INSERT INTO CadastroUsuario (nome, sobrenome, email, senha, telefone, sexo)
  VALUES(:nome, :sobrenome, :email, :senha, :telefone, :sexo)";
  $stmt = $conn->prepare($sql);
  $stmt->bindValue(":nome",$nome);
  $stmt->bindValue(":sobrenome",$sobrenome);
  $stmt->bindValue(":email",$email);
  $stmt->bindValue(":senha",$senha);
  $stmt->bindValue(":telefone",$telefone);
  $stmt->bindValue(":sexo",$sexo);
  $stmt->execute();
?>
<?php
  $sql = "SELECT * FROM CadastroUsuario WHERE (email = :email) AND (senha = :senha)";
  $stmt = $conn->prepare($sql);
  $stmt->bindValue(':email', $email);
  $stmt->bindValue(':senha', $senha);
  $stmt->execute();
  $CadastroUsusario = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // pega o primeiro usuário
    $user = $CadastroUsusario[0];
    
    session_start();
    $_SESSION['logged_in'] = true;
    $_SESSION['id'] = $user['id'];
    $_SESSION['nome'] = $user['nome'];
    $_SESSION['sobrenome'] = $user['sobrenome'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['telefone'] = $user['telefone'];
    $_SESSION['sexo'] = $user['sexo'];
  header('Location: Perfil.php');

?>