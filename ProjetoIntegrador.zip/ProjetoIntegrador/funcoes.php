<?php

class funcoes {
    $resultado = false;
    if (isset($_SESSION["email-cadastro"])) {
        $resultado = true;
    }
}


?>