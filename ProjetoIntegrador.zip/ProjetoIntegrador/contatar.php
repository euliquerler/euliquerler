<?php

    require 'PHPMailer/PHPMailerAutoload.php';

    $emailrem = $_GET["email-contato"];
    ini_set('display_errors', 1);
 
    error_reporting(E_ALL);
    
    $from =  $_GET["email-contato"];
    
    $to = "thaissalves13.07@gmail.com";
    
    $subject = $_GET["assunto"];
    
    $message = $_GET["msg"];
    
    $headers = "De:". $from;
    
    mail($to, $subject, $message, $headers);
    
    echo "A mensagem de e-mail foi enviada.";
  ?>