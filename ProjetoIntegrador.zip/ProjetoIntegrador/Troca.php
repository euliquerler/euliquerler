<body>
<?php
  include_once ("_cabecalho.php");
?>  

<?php
  include_once ("_rodape.php");
?>  
