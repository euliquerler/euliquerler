<?php 
 include_once ("init.php");
 include_once ("connection.php");
 include_once ("Function.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Eu li, quer ler?</title>
  <link rel="stylesheet" type="text/css" href="css/css.css" />
  <link rel="shortcut icon" href="Imagens/LogoVinho.png" type="image/x-icon">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script type="text/javascript" src="validacao.js"></script>


</head>
<body>
  <nav class="navbar navbar-dark  navbar-expand-lg" style="background-color:#810006">
        <a class="navbar-brand" href="paginainicial.php"><img src="Imagens/LogoVinho.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="paginainicial.php">Início <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="Perfil.php">Perfil <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Categorias
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="Doacao.php">Doação</a>
                <a class="dropdown-item" href="Emprestimos.php">Empréstimo</a>
                <a class="dropdown-item" href="Troca.php">Troca</a>
              </div>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="Contato.php">Contato</a>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <a href="Login.php"><button id="login" class="btn btn-outline-light" type="button"> Entrar</button></a>
            <a href="Cadastro.php"><button id="login" style="margin-left: 5px"  class="btn btn-outline-light" type="button"> Cadastre-se</button></a>
          </form>
        </div>
      </nav>
     
</body>
</html>