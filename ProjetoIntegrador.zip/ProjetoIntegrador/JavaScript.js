function VazioNulo(str) { // função para comparar se o elemento é nulo ou vazio
    var v = document.getElementById(str).value;
    return v == null || v.trim() == "";
    }
    if (form.addEventListener){
     form.addEventListener("submit",validarCadastro());
    }else if (form.attachEvent) {
        form.attachEvent("onsubmit",validarCadastro()); 
    }
    if (form.addEventListener){
        form.addEventListener("submit",validarCadastroLi());
    }else if (form.attachEvent) {
        form.attachEvent("onsubmit",validarCadastroLi());
    }
  function validarCadastro(){
       /* Validação do campo nome para que não seja vazio ou nulo, utilizando a função*/
	     if(VazioNulo('nome') || document.formulario-cadastro.nome.value.length < 3 || document.formulario-cadastro.nome.value.length > 60){
            alert("Digite um nome válido");
         document.FormCadPessoa.nome.focus(); // se for de acordo de acordo com as instruções e não for valido, volta para o campo nome nesse caso
         return false; // retorna falso para que não haja reposta ao formulário e sim volte para onde errou.
       }
       //Validação do sobrenome
       if(VazioNulo('sobrenome') || document.formulario-cadastro.sobrenome.value.length < 3 || document.formulario-cadastro.nome.value.length > 40){
         alert("Digite um sobrenome válido");
         document.formulario-cadastro.sobrenome.focus();
         return false;
       }
       // verifica se o número tem os números necessários
       if (VazioNulo('telefone')) {
         alert("Por favor, digite seu número com o DDD.");
         document.formulario-cadastro.telefone.focus();
         return false;
       }else {
         if (document.getElementById('telefone').lenght<12) {
           alert("Por favor, digite seu número com o DDD");
           document.formulario-cadastro.telefone.focus();
           return false;
         }
        }
      //verifica se uma das opções estão selecionadas, varificando se o valor é vazio, sendo este o valor da opção padrão
       if(document.formulario-cadastro.sltSexo.value == ""){
         alert("Escolha uma das opções.");
         document.getElementById("sexo").focus();
         return false;
        }
      //faz a verificação do email é válida, vendo se possui um ponto, pois o @ já é necessitado pelo próprio tipo
        if (document.formulario-cadastro.email-cadastro.value == ""){
            alert("Preencha o campo email.");
            document.getElementById("email-cadastro").focus();
            return false;
        }else{
        if(document.formulario-cadastro.email-cadastro.value.indexOf(".") == -1) //verifica se o email tem .//
        {
          alert("Email Inválido");
          document.getElementById("email-cadastro").focus();
          return false;
        }
        return false;
      }
      //verifica se a senha tem um tamanho razoável
      if (formulario-cadastro.senha-cadastro.value=="" || formulario-cadastro.senha-cadastro.value.length < 5 || formulario-cadastro.senha-cadastro.value.length > 20  ) {
        alert("Coloque uma senha válida.");
        document.getElementById("senha-cadastro").focus();
      }
      // verifica se a senha é igual a confirmação de senha
      if (formulario-cadastro.senha-cadastro.value != formulario-cadastro.ConfirmSenha.value) {
        alert("As senhas não são iguais, digite novamente.");
        document.getElementById("ConfirmSenha").focus();
        return false;
      } return true;
}