  <?php
    include_once ("_cabecalho.php");
  ?>      
  <div class="row">
    <div class="col-xs-12 col-md-6 contato-imagem">
      <img src="Imagens/imagemcontato.webp" height="500px" width="350px" alt="Imagem pilha de livros">
    </div>
    <div class="col-xs-12 col-md-6 ">
      <div class="contato">
        <h1>Entre em contato conosco</h1>
        <p>Precisa entrar em contato? Fale conosco.
         Gostaríamos muito de ouvir você.
        </p>
        <p id="email-eu-li">
         euliquerler@gmail.com
        <br>
          3696-0267
        </p>
        <form action="" style="width: 90%">
        <input type="text" class="form-control" name="nome" id="nome-contato" placeholder="Nome"  required>
        <input type="email"class="form-control"  name="email" id="email-contato" placeholder="Email" required>
        <input type="text" class="form-control" name="assunto" id="assunto-contato" placeholder="Assunto">
        <textarea name="mensagem"class="form-control" id="mensagem-contato" cols="20" rows="5" required placeholder="Mensagem"></textarea>              
        <button type="submit" class="btn">Enviar</button>
        </form>
      </div>
    </div>
  </div>
  <?php
    include_once ("_rodape.php");
  ?>    
