
<?php
  include_once ("_cabecalho.php");
  include_once ("connection.php");
  $conn = getConnection();
  $categoria = isset($_POST["categoria"]) ? $_POST["categoria"]:'';

  $sql = "SELECT * FROM CadastroLivro WHERE (categoria='Doações')";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $CadastroDoacao = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (count($CadastroDoacao) <= 0)
  {
      echo "Não encontrado";
      exit;
  }

?> 
  <meta http-equiv="refresh" content="30">

<div class="container">
  <div class="row">
    <?php
      foreach ($CadastroDoacao as $value) { ?>
      <div class="card col-xs-12 col-sm-6 col-md-4" style="width: 18rem;">
        <div class="card-body">
          <h5 class="card-title"><?= $value["titulo"] ?></h5>
          <h6 class="card-subtitle mb-2 text-muted"><?= $value["autor"] ?></h6>
          <p class="card-text">Sinopse: <?= $value["sinopse"] ?></p>
          <a href="universal.php?id=<?= $value["idLivro"] ?>" class="btn">Mais informações</a>
        </div>
      </div>
        <?php
      }?>
      
        
  </div>
</div>
<?php
  include_once ("_rodape.php");
?>    
