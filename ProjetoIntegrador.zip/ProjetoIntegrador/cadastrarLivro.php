<?php
  session_start();
  include_once ('Function.php');
  include_once ('init.php');

  exec("SET CHARACTER SET utf8");
  include_once ("connection.php");
  $conn = getConnection();
  $titulo = isset($_POST["titulo"]) ? $_POST["titulo"]:'';
  $autor = isset($_POST["autor"]) ? $_POST["autor"]:'';
  $genero = isset($_POST["genero"]) ? $_POST["genero"]:'';
  $ano = isset($_POST["ano"]) ? $_POST["ano"]:'';
  $editora = isset($_POST["editora"]) ? $_POST["editora"]:'';
  $categoria = isset($_POST["categoria"]) ? $_POST["categoria"]:'';
  $sinopse = isset($_POST["sinopse"]) ? $_POST["sinopse"]:'';
  $imagem = isset($_POST["imagemLivro"]) ? $_POST["imagemLivro"]:'';

  if (isLoggedIn())
  {
    $proprietario = $_SESSION['id'];
  }
  if (empty($titulo) || empty($autor) || empty($genero) || empty($ano) || empty($editora) || empty($categoria) || empty($sinopse)) {
      echo "Preencha todos os dados!";
      exit;
  }
  if (empty($proprietario)){
      echo "Sem dados do proprietário";
      exit;
  }
  $sql = "INSERT INTO CadastroLivro (titulo, autor, genero, ano, editora, categoria, sinopse, proprietario, imagemLivro)
  VALUES(:titulo, :autor, :genero, :ano, :editora, :categoria, :sinopse, :proprietario, :imagemLivro)";
  $stmt = $conn->prepare($sql);
  $stmt->bindValue(":titulo",$titulo);
  $stmt->bindValue(":autor",$autor);
  $stmt->bindValue(":genero",$genero);
  $stmt->bindValue(":ano",$ano);
  $stmt->bindValue(":editora",$editora);
  $stmt->bindValue(":categoria",$categoria);
  $stmt->bindValue(":sinopse",$sinopse);
  $stmt->bindValue(":proprietario",$proprietario);
  $stmt->bindValue(":imagemLivro",$imagem);
  $stmt->execute();
?>
<?php
  $sql = "SELECT * FROM CadastroLivro WHERE (categoria='Doações')";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $CadastroDoacao = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (count($CadastroDoacao) <= 0)
  {
      echo "Não encontrado";
      exit;
  }
 
// pega o primeiro usuário
$doacao = $CadastroDoacao[0];
  $_SESSION['titulo'] = $doacao['titulo'];
  $_SESSION['autor'] = $doacao['autor'];
  $_SESSION['genero'] = $doacao['genero'];
  $_SESSION['ano'] = $doacao['ano'];
  $_SESSION['editora'] = $doacao['editora'];
  $_SESSION['proprietario'] = $doacao['proprietario'];
  $_SESSION['categoria'] = $doacao['categoria'];
  $_SESSION['sinopse'] = $doacao['sinopse'];
  $_SESSION['imagemLivro'] = $doacao['imagemLivro'];

  $sql = "SELECT * FROM CadastroLivro WHERE (categoria='Empréstimos')";
  $stmt = $conn->prepare($sql);
  $CadastroEmprestimo = $stmt->fetchAll(PDO::FETCH_ASSOC);
  $_SESSION['titulo'] = $CadastroEmprestimo['titulo'];
  $_SESSION['autor'] = $CadastroEmprestimo['autor'];
  $_SESSION['genero'] = $CadastroEmprestimo['genero'];
  $_SESSION['ano'] = $CadastroEmprestimo['ano'];
  $_SESSION['editora'] = $CadastroEmprestimo['editora'];
  $_SESSION['proprietario'] = $CadastroEmprestimo['proprietario'];
  $_SESSION['categoria'] = $CadastroEmprestimo['categoria'];
  $_SESSION['sinopse'] = $CadastroEmprestimo['sinopse'];
  $_SESSION['imagemLivro'] = $CadastroEmprestimo['imagemLivro'];

  $sql = "SELECT * FROM CadastroLivro WHERE (categoria='Trocas')";
  $stmt = $conn->prepare($sql);
  $CadastroTrocas = $stmt->fetchAll(PDO::FETCH_ASSOC);
  $_SESSION['titulo'] = $CadastroTrocas['titulo'];
  $_SESSION['autor'] = $CadastroTrocas['autor'];
  $_SESSION['genero'] = $CadastroTrocas['genero'];
  $_SESSION['ano'] = $CadastroTrocas['ano'];
  $_SESSION['editora'] = $CadastroTrocas['editora'];
  $_SESSION['proprietario'] = $CadastroTrocas['proprietario'];
  $_SESSION['categoria'] = $CadastroTrocas['categoria'];
  $_SESSION['sinopse'] = $CadastroTrocas['sinopse'];
  $_SESSION['imagemLivro'] = $CadastroTrocas['imagemLivro'];

  header('Location: Perfil.php');

?>

