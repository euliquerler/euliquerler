<?php 
 
 function getConnection(){

  $dsn = 'mysql:host=127.0.0.1;dbname=Eu_li_quer_ler; charset=utf8';
  $user = 'root';
  $pass = '130700';

  try{
    $db = new PDO($dsn,$user, $pass);
    
  }catch(PDOException $ex){
    throw new PDOException($e);  }
  return $db;
 }

?>