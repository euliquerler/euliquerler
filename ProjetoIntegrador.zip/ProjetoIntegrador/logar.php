<?php 
include_once ("connection.php");
include_once ('Function.php');
include_once ("init.php");
$conn = getConnection();
$email = isset($_POST['email-login']) ? $_POST['email-login']:'';
$senha = isset($_POST['senha-login']) ? $_POST['senha-login']:'';

if (empty($email) ||empty($senha)) {
    echo "Informe email e senha.";
    exit;
}
$sql = "SELECT * FROM CadastroUsuario WHERE (email = :email) AND (senha = :senha)";
$stmt = $conn->prepare($sql);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':senha', $senha);
$stmt->execute();
$CadastroUsusario = $stmt->fetchAll(PDO::FETCH_ASSOC);
 
if (count($CadastroUsusario) <= 0)
{
    echo "Email ou senha incorretos";
    exit;
}
 
// pega o primeiro usuário
$user = $CadastroUsusario[0];
 
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['id'] = $user['id'];
$_SESSION['nome'] = $user['nome'];
$_SESSION['sobrenome'] = $user['sobrenome'];
$_SESSION['email'] = $user['email'];
$_SESSION['telefone'] = $user['telefone'];
$_SESSION['sexo'] = $user['sexo'];

 
header('Location: Perfil.php');
?>