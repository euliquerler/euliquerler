<?php
  include_once ("_cabecalho.php");
  session_start();

?>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="d-block w-100" src="Imagens/livros1.jpg" alt="First slide" height="500 px" width="100">
            <div class="carousel-caption d-none d-md-block">
              <h1> <a href="Doacao.php" >Doações</a> </h1>
              <p>Categoria de livros para doação</p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="Imagens/livros2.jpg" alt="Second slide" height="500 px" width="100">
            <div class="carousel-caption d-none d-md-block">
              <h1> <a href="Emprestimos.php"> Empréstimos</a> </h1>
              <p>Categoria de livros para emprestimo</p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="Imagens/livros-3.jpg" alt="Third slide" height="500 px" width="100">
            <div class="carousel-caption d-none d-md-block">
              <h1 > <a href="Troca.php" >Trocas</a> </h1>
              <p>Categoria de livros para troca</p>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

      <div class="row">
        <div class="col-xs-12 col-md-6 inicial-imagem">
          <img src="Imagens/paginainicial.jpg" class="img-thumbnail img-responsive" alt="Imagem do livros abertos">
        </div>
        <div class="col-xs-12 col-md-6">
          <div class="inicial">
              <h1>Sobre <i>Eu li, quer ler?</i></h1>
              <p>O <i>Eu li, quer ler?</i> é uma iniciativa de duas alunas do IFRN, que com a ideia de compartilhar livros
              decidiram fundar um site para o aproveitamento de livros já lidos, e que estão parados na estante,
              através de doações, empréstimos ou trocas. O objetivo em criar esse site é compartilhar experiências
              literárias. Todo mundo tem aquele livro que ama e tem certeza que outra pessoa vai amar também.
              Então, por que guardar esse livro se podemos compartilhar e fazer com que outras pessoas
              tenham acesso a ele? Mas nossa iniciativa não se resume apenas a emprestar livros, nós também temos o intuito
              de trocar livros e doá-los, tanto para termos um novo livro na estante como para incentivar alguém a ler.</p>
              <a href="Contato.php"><h6>Entre em contato</h6></a>
              <br>
          </div>
        </div>
      </div>
<?php
  include_once ("_rodape.php");
?>

